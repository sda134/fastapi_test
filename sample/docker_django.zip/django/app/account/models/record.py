from django.db import models
from django.utils import timezone           # timezone.now
from django.forms import widgets

from account.models.others import AccountCategory, AccountResource

# Create your models here.

class AccountRecord(models.Model):
    class Meta:
        app_label = 'account'
        db_table = 'account_records'

    date = models.DateField(default=timezone.now)
    ammount = models.IntegerField(default=0)
    resource = models.ForeignKey(AccountResource, models.SET_NULL, null=True, blank=True)
    category = models.ForeignKey(AccountCategory, models.SET_NULL, null=True, blank=True)
    memo = models.TextField(null=True, blank=True)

