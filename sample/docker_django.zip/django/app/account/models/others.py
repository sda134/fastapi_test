from django.db import models

class AccountResource(models.Model):
    name = models.CharField(max_length=128)
    class Meta:
        app_label = 'account'
        db_table = 'account_resources'
        verbose_name_plural = 'AccountResources'
    def __str__(self):
        return self.name

class AccountCategory(models.Model):
    name = models.CharField(max_length=128)
    class Meta:
        app_label = 'account'
        db_table = 'account_categories'
        verbose_name_plural = 'AccountCategories'
    def __str__(self):
        return self.name