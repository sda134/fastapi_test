from django.urls import include, path
from . import views

app_name="account"

urlpatterns = [
    path('list/', views.account_redirect_view, name='account_top'),
    path('list/<str:date_str>', views.AccountListView.as_view(), name='account_list'),
    path('add/<str:date_str>', views.AccountAddView.as_view(), name='account_add'),
    path('edit/<int:id>', views.AccountEditView.as_view(), name='account_edit'),
]