function changeColor(newColor) {
    var elem = document.getElementById("para1");
    elem.style.color = newColor;
  }

  
const keyword_element = document.getElementById('keyword');
keyword_element.addEventListener('keyup', e => {
    console.log('keyup');
});