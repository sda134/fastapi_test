from django import forms
from django.db import models
from django.forms import widgets
from django.contrib.admin.widgets import AdminDateWidget
from .models import AccountRecord

class RecordSumupForm(forms.Form):
    year = forms.fields.ChoiceField(
        label='年',
        choices = (('2022', 2022), ('2023', 2023), ),
        widget=forms.widgets.Select
    )
    month = forms.fields.ChoiceField(
        label='月',
        choices = [(str(m), m) for m in range(1, 13)],
        widget=forms.widgets.Select
    )
    

class RecordSearchForm(forms.Form):
    date_from = forms.DateField(
        label='日付from',
        widget = widgets.DateInput(format='%Y-%m-%d', attrs={'type':'date'}),
    )
 
    date_to = forms.DateField(
        label='日付to',
        widget = widgets.DateInput(format='%Y-%m-%d', attrs={'type':'date'}),
    )

class RecordEditForm(forms.ModelForm):
    class Meta:
        model = AccountRecord
        fields=["ammount", "resource", "category", "date", "memo"]  # '__all__' でも良い
        labels = {
            'ammount' : '金額',
            'category' : '区分',
            'resource' : '出費元',
            'date' : '日付',
            'memo' : 'メモ',
        }

        widgets = {
            'date' : forms.DateInput(format='%Y-%m-%d', attrs={'type':'date'})
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)