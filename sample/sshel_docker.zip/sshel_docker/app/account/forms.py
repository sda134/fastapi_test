from django import forms
from django.db import models
from django.forms import widgets
from django.contrib.admin.widgets import AdminDateWidget
from .models import AccountRecord


class RecordListForm(forms.Form):
    selected_date = forms.DateField(widget = widgets.DateInput())

class RecordEditForm(forms.ModelForm):
    class Meta:
        model = AccountRecord
        fields=["ammount", "resource", "category", "date", "memo"]  # '__all__' でも良い
        labels = {
            'ammount' : '金額',
            'category' : '区分',
            'resource' : '出費元',
            'date' : '日付',
            'memo' : 'メモ',
        }

        widgets = {
            'date' : forms.DateInput(format='%Y-%m-%d', attrs={'type':'date'})
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)