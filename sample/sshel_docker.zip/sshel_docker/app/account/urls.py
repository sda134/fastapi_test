from django.urls import include, path
from . import views

app_name="account"

urlpatterns = [
    #path('list/', views.account_redirect_view, name='account_top'),
    path('list/', views.AccountListView.as_view(), name='account_list'),
    path('add/', views.AccountAddView.as_view(), name='account_add'),
    path('edit/<int:id>', views.AccountEditView.as_view(), name='account_edit'),
    path('sumup/', views.AccountSumupView.as_view(), name='account_sumup'),
    path('csv/', views.AccountCsvView.as_view(), name='account_csv'),
    path('csv_read/', views.AccountCsvReadView.as_view(), name='account_csv_read'),
]