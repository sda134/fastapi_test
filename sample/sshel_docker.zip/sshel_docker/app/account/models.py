from django.db import models
from django.utils import timezone           # timezone.now
from django.forms import widgets
from django.contrib.auth.models import AbstractBaseUser
# Create your models here.

class AccountResource(models.Model):
    name = models.CharField(max_length=128)
    class Meta:
        db_table = 'account_resources'
        verbose_name_plural = 'AccountResources'
    def __str__(self):
        return self.name

class AccountCategory(models.Model):
    name = models.CharField(max_length=128)
    class Meta:
        db_table = 'account_categories'
        verbose_name_plural = 'AccountCategories'
    def __str__(self):
        return self.name


class AccountRecord(models.Model):
    class Meta:
        db_table = 'account_records'

    date = models.DateField(default=timezone.now)
    ammount = models.IntegerField(default=0)
    resource = models.ForeignKey(AccountResource, on_delete=models.SET_NULL, null=True, blank=True)
    category = models.ForeignKey(AccountCategory, on_delete=models.SET_NULL, null=True, blank=True)
    memo = models.TextField(null=True, blank=True)


class SShelUser (AbstractBaseUser):
    username = models.CharField(max_length=150, unique=True)
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []