import calendar
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
from re import search
from django.db.models import Sum, Q
from django.db.models.query import InstanceCheckMeta
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.contrib import messages
from django.views.generic import TemplateView, ListView, RedirectView
from django.db.models import Sum
from .models import AccountRecord, AccountCategory
from .forms import RecordEditForm, RecordSearchForm, RecordSumupForm

#class AccountRedirectView(RedirectView):
#    date_str = datetime.now().strftime('%Y%m%d')
#    url =reverse("account:account_list")
    #return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))

# def account_redirect_view(request):
#     date_str = datetime.now().strftime('%Y-%m-%d')
#     return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))



class AccountListView(ListView):
    model = AccountRecord
    template_name = 'account/list.html'
    context_object_name	 = 'record_list'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        dt_from = (datetime.now() - relativedelta(weeks=1)).date()
        dt_to = datetime.now().date()
        
        query_dt_from = self.request.GET.get('date_from', None)
        query_dt_to = self.request.GET.get('date_to', None)
        
        if query_dt_from:
            dt_from = datetime.strptime(query_dt_from, '%Y-%m-%d').date()
        if query_dt_to:
            dt_to = datetime.strptime(query_dt_to, '%Y-%m-%d').date()

        context['search_form'] = RecordSearchForm(
            initial={
                'date_from' : dt_from,
                'date_to' : dt_to,
            },
        )
        return context


    def get_queryset(self):     # 主に ListViewで用いられるメソッド（override）       
        dt_from = (datetime.now() - relativedelta(weeks=1)).date()
        dt_to = datetime.now().date()

        query_dt_from = self.request.GET.get('date_from', None)
        query_dt_to = self.request.GET.get('date_to', None)
 
        if query_dt_from:
            dt_from = datetime.strptime(query_dt_from, '%Y-%m-%d').date()
        if query_dt_to:
            dt_to = datetime.strptime(query_dt_to, '%Y-%m-%d').date()

        return AccountRecord.objects \
            .filter(date__range=[dt_from, dt_to]) \
            .order_by('date', 'category') \
            .all()



class AccountAddView(TemplateView):
    def get(self, request, *args, **kwargs):
        context={
            'form' : RecordEditForm(initial =
            {
                'date' : datetime.today(),
            }),
        }
        return render(request, 'account/add.html', context)


    def post(self, request, *args, **kwargs):
        form = RecordEditForm(request.POST)
        context={
            'form' : form,
        }
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/add.html', context)        
        record = form.save()
        return redirect(reverse("account:account_list"))        



class AccountEditView(TemplateView):
    def get(self, request, id, *args, **kwargs):
        record = get_object_or_404(AccountRecord, pk=id)
        form = RecordEditForm(initial =
        {
            'ammount' : record.ammount,
            'resource' : record.resource,
            'category' : record.category,
            'date' : record.date,
            'memo' : record.memo,
        })
        context={
            'record' : record,
            'form' : form,
        }
        return render(request, 'account/edit.html', context)


    def post(self, request, id, *args, **kwargs):
        record = get_object_or_404(AccountRecord, pk=id)
        form = RecordEditForm(request.POST, instance = record)
        context={
            'record' : record,
            'form' : form,
        }
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/edit.html', context)        

        form.save()
        return redirect(reverse("account:account_list"))



class AccountSearchView(ListView):
    model = AccountRecord
    template_name = 'account/search.html'
    

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        dt_from_str = self.request.GET.get('date_from', None)
        dt_to_str = self.request.GET.get('date_to', None)

        if not (dt_from_str):
            dt_from_str = (datetime.now().date() - relativedelta(weeks=1)).strftime('%Y-%m-%d')
        if not(dt_to_str):
            dt_to_str = datetime.now().strftime('%Y-%m-%d')

        context['dt_from_str'] = dt_from_str
        context['dt_to_str'] = dt_to_str
        return context


    def get_queryset(self):     # 主に ListViewで用いられるメソッド（override）       
        dt_from = (datetime.now() - relativedelta(weeks=1)).date()
        dt_to = datetime.now().date()

        query_dt_from = self.request.GET.get('date_from', None)
        query_dt_to = self.request.GET.get('date_to', None)
 
        if query_dt_from:
            dt_from = datetime.strptime(query_dt_from, '%Y-%m-%d').date()
        if query_dt_to:
            dt_to = datetime.strptime(query_dt_to, '%Y-%m-%d').date()

        return AccountRecord.objects \
            .filter(date__range=[dt_from, dt_to]) \
            .order_by('date', 'category') \
            .all()
        


class AccountSumupView(ListView):
    def get(self, request, *args, **kwargs):
        year=datetime.today().year
        month=datetime.today().month

        query_year = request.GET.get('year', None)
        query_month = request.GET.get('month', None)

        if query_year:
            year = int(query_year)
        if query_month:
            month = int(query_month)

        dummy, last_day = calendar.monthrange(year, month)
        dt_from = date(year, month, 1)
        dt_to = date(year, month, last_day)

        category_sumup = AccountRecord.objects \
            .values('category__name', ) \
            .filter(date__range=[dt_from, dt_to]) \
            .annotate(sum = Sum('ammount')) \
            .order_by('category__id')

        total_sumup_list=list(category_sumup.values_list('sum'))
        total=0
        for val in total_sumup_list:
            total+=val[0]

        context={
            'category_sumup' : category_sumup,
            'total' : total,
            'form' : RecordSumupForm(initial =
            {
                'year' : year,
                'month' : month,
            }),
        }

        return render(request, 'account/sumup.html', context)
