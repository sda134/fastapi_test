import calendar
import io,csv
from datetime import date, datetime
import resource
from unicodedata import category
from dateutil.relativedelta import relativedelta
from re import search
from django.db.models import Sum, Q
from django.db.models.query import InstanceCheckMeta
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.contrib import messages
from django.utils.http import urlencode
from django.views.generic import TemplateView, ListView, RedirectView, FormView
from django.db.models import Sum
from .models import AccountRecord, AccountCategory, AccountResource
from .forms import RecordEditForm, RecordSearchForm, RecordSumupForm, CsvUploadForm

#class AccountRedirectView(RedirectView):
#    date_str = datetime.now().strftime('%Y%m%d')
#    url =reverse("account:account_list")
    #

# def account_redirect_view(request):
#     date_str = datetime.now().strftime('%Y-%m-%d')
#     return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))



class AccountListView(ListView):
    model = AccountRecord
    template_name = 'account/list.html'
    context_object_name	 = 'record_list'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        dt_from = (datetime.now() - relativedelta(weeks=1)).date()
        dt_to = datetime.now().date()
        
        query_dt_from = self.request.GET.get('date_from', None)
        query_dt_to = self.request.GET.get('date_to', None)
        
        if query_dt_from:
            dt_from = datetime.strptime(query_dt_from, '%Y-%m-%d').date()
        if query_dt_to:
            dt_to = datetime.strptime(query_dt_to, '%Y-%m-%d').date()

        context['search_form'] = RecordSearchForm(
            initial={
                'date_from' : dt_from,
                'date_to' : dt_to,
            },
        )
        return context


    def get_queryset(self):     # 主に ListViewで用いられるメソッド（override）       
        dt_from = (datetime.now() - relativedelta(weeks=1)).date()
        dt_to = datetime.now().date()

        query_dt_from = self.request.GET.get('date_from', None)
        query_dt_to = self.request.GET.get('date_to', None)
 
        if query_dt_from:
            dt_from = datetime.strptime(query_dt_from, '%Y-%m-%d').date()
        if query_dt_to:
            dt_to = datetime.strptime(query_dt_to, '%Y-%m-%d').date()

        return AccountRecord.objects \
            .filter(date__range=[dt_from, dt_to]) \
            .order_by('-date', 'category') \
            .all()



class AccountAddView(TemplateView):
    def get(self, request, *args, **kwargs):
        context={
            'form' : RecordEditForm(initial =
            {
                'date' : datetime.today(),
            }),
        }
        return render(request, 'account/add.html', context)


    def post(self, request, *args, **kwargs):
        form = RecordEditForm(request.POST)
        context={
            'form' : form,
        }
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/add.html', context)        
        record = form.save()
        date_str = record.date.strftime('%Y-%m-%d')
        return redirect(reverse("account:account_list"))        



class AccountEditView(TemplateView):
    def get(self, request, id, *args, **kwargs):
        record = get_object_or_404(AccountRecord, pk=id)
        form = RecordEditForm(initial =
        {
            'ammount' : record.ammount,
            'resource' : record.resource,
            'category' : record.category,
            'date' : record.date,
            'memo' : record.memo,
        })
        context={
            'record' : record,
            'form' : form,
        }
        return render(request, 'account/edit.html', context)


    def post(self, request, id, *args, **kwargs):
        record = get_object_or_404(AccountRecord, pk=id)
        form = RecordEditForm(request.POST, instance = record)
        context={
            'record' : record,
            'form' : form,
        }
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/edit.html', context)        

        form.save()
        
        date_str = record.date.strftime('%Y-%m-%d')
        return redirect(reverse("account:account_list"))



class AccountSearchView(ListView):
    model = AccountRecord
    template_name = 'account/search.html'
    

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        dt_from_str = self.request.GET.get('date_from', None)
        dt_to_str = self.request.GET.get('date_to', None)

        if not (dt_from_str):
            dt_from_str = (datetime.now().date() - relativedelta(weeks=1)).strftime('%Y-%m-%d')
        if not(dt_to_str):
            dt_to_str = datetime.now().strftime('%Y-%m-%d')

        context['dt_from_str'] = dt_from_str
        context['dt_to_str'] = dt_to_str
        return context


    def get_queryset(self):     # 主に ListViewで用いられるメソッド（override）       
        dt_from = (datetime.now() - relativedelta(weeks=1)).date()
        dt_to = datetime.now().date()

        query_dt_from = self.request.GET.get('date_from', None)
        query_dt_to = self.request.GET.get('date_to', None)
 
        if query_dt_from:
            dt_from = datetime.strptime(query_dt_from, '%Y-%m-%d').date()
        if query_dt_to:
            dt_to = datetime.strptime(query_dt_to, '%Y-%m-%d').date()

        return AccountRecord.objects \
            .filter(date__range=[dt_from, dt_to]) \
            .order_by('date', 'category') \
            .all()



class AccountSumupDetailView(ListView):
    template_name = 'account/sumup_detail.html'
    #context_object_name	 = 'record_list'
    model = AccountRecord

   
    def get(self, request, id, *args, **kwargs):
        if id==0:
            category = None
        else:
            category = AccountCategory.objects.get(pk=id)
        
        year=datetime.today().year
        month=datetime.today().month

        query_year = self.request.GET.get('year', None)
        query_month = self.request.GET.get('month', None)

        if query_year:
            year = int(query_year)
        if query_month:
            month = int(query_month)

        dummy, last_day = calendar.monthrange(year, month)
        dt_from = date(year, month, 1)
        dt_to = date(year, month, last_day)

        query_set = AccountRecord.objects \
            .filter(date__range=[dt_from, dt_to], category=category) \
            .all()
        
        context={
            'record_list' : query_set,
        }

        return render(request, 'account/sumup_detail.html', context)




class AccountSumupView(ListView):
    def get(self, request, *args, **kwargs):
        year=datetime.today().year
        month=datetime.today().month

        query_year = request.GET.get('year', None)
        query_month = request.GET.get('month', None)

        if query_year:
            year = int(query_year)
        if query_month:
            month = int(query_month)

        dummy, last_day = calendar.monthrange(year, month)
        dt_from = date(year, month, 1)
        dt_to = date(year, month, last_day)

        category_sumup = AccountRecord.objects \
            .values('category__name', 'category__id') \
            .filter(date__range=[dt_from, dt_to]) \
            .annotate(sum = Sum('ammount')) \
            .order_by('category__id')

        total_sumup_list=list(category_sumup.values_list('sum'))
        total=0
        for val in total_sumup_list:
            total+=val[0]

        context={
            'category_sumup' : category_sumup,
            'total' : total,
            'form' : RecordSumupForm(initial =
            {
                'year' : year,
                'month' : month,
            }),
            'year' : year,
            'month' : month,
        }

        return render(request, 'account/sumup.html', context)



class AccountCsvRecordSelectView(TemplateView):
    def get(self, request, *args, **kwargs):
        #csv_list = request.session.get('csv_list')
        record_list = request.session.get('record_list')
        selected_list = request.session.get('selected_list')
        category_list = AccountCategory.objects.values('id', 'name')
        context={
            'record_list' : record_list,
            'selected_list' : selected_list,
            'category_list' : category_list,            
        }

        return render(request, 'account/csv_record.html', context)


    def post(self, request, *args, **kwargs):
        record_list = request.session.get('record_list')
        c=0
        for rec in record_list:
            chk_str = 'checked_%s' % str(c)
            chk_val = request.POST.get(chk_str, None)
            if chk_val=='on':
                cat_str = 'category_%s' % str(c)
                cat_val = request.POST.get(cat_str, None)

                rs_id = int(request.session.get('resource_id'))
                resource = AccountResource.objects.get(pk=rs_id)
                category = AccountCategory.objects.get(pk=int(cat_val))

                print('resource:%s' % (resource))

                record = AccountRecord.objects.create(
                    date = datetime.strptime(rec['date'], '%Y/%m/%d').date(),
                    ammount = int(rec['ammount']),
                    category = category,
                    resource = resource,
                    memo = rec['memo'],
                )
                #print('%s %s account:%s' % (cat_str,cat_val, record.category))
            c+=1

        return redirect(reverse('account:account_list'))



class AccountCsvColumnSelectView(TemplateView):
    def get(self, request, *args, **kwargs):
        csv_list = request.session.get('csv_list')
        resource_list = AccountResource.objects.values('id', 'name')
        max_clm = max(csv_list, key=lambda row:len(row))
        context={
            'csv_list' : csv_list,
            'resource_list' : resource_list,
            'column_range' : range(len(max_clm)),
        }
        return render(request, 'account/csv_column.html', context)


    def post(self, request, *args, **kwargs):
        clm_date = int(request.POST.get('clm_date', None))
        clm_ammount = int(request.POST.get('clm_ammount', None))
        clm_memo = int(request.POST.get('clm_memo', None))

        csv_list = request.session.get('csv_list')
        resource_list = AccountResource.objects.values('id', 'name')
        max_clm = max(csv_list, key=lambda row:len(row))
        context={
            'csv_list' : csv_list,
            'resource_list' : resource_list,
            'column_range' : range(len(max_clm)),
        }
        if (clm_date == clm_ammount) or (clm_date == clm_memo) or (clm_ammount == clm_memo):
            messages.info(request, '同じ行を選択しないで下さい')
            return render(request, 'account/csv_column.html', context)
        

        record_list=[]
        for row in csv_list:
            try:
                rec = AccountRecord(
                    date = datetime.strptime(row[clm_date], '%Y/%m/%d'),
                    ammount = int(row[clm_ammount]),
                    memo = row[clm_memo],
                )

                rec_existed = AccountRecord.objects.filter(date=rec.date, ammount=rec.ammount).exists()
                # if rec_existed:
                #     print('already exists! data:%s ammount:%s' % (rec.date, rec.ammount))

                record_list.append(
                    {
                        "selected" : rec_existed,
                        "date" : row[clm_date],
                        "ammount" : row[clm_ammount],
                        "memo" : row[clm_memo],
                    })
                #print('succeed!:%s' % row[0])
            except:
                print('exception!:%s' % row[0])

        resource_id = request.POST.get('resource', None)
        request.session['resource_id']= resource_id             # json にシリアライズ出来ないとダメらしい
        request.session['record_list']= record_list             # json にシリアライズ出来ないとダメらしい

        return redirect(reverse('account:account_csv_record'))



class AccountCsvView(TemplateView):
    def get(self, request, *args, **kwargs):
        form = CsvUploadForm()
        context={
            'form' : form,
        }
        return render(request, 'account/csv.html', context)


    def post(self, request, *args, **kwargs):
        request_csv = request.FILES['csvfile']
        form = CsvUploadForm(request.POST, initial={
            'csvfile' : request_csv
        })
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/csv.html', { 'form' : form })
        
        csvfile = io.TextIOWrapper(form.cleaned_data['csvfile'], encoding='shift-jis')
        csv_list = list(csv.reader(csvfile))
        request.session['csv_list']= csv_list             # json にシリアライズ出来ないとダメらしい
        return redirect(reverse('account:account_csv_clumn'))
