from datetime import date, datetime
from django.db.models import Sum
from django.db.models.query import InstanceCheckMeta
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.contrib import messages
from django.views.generic import TemplateView, ListView, RedirectView
from .models import AccountRecord, AccountCategory
from .forms import RecordEditForm, RecordListForm


#class AccountRedirectView(RedirectView):
#    date_str = datetime.now().strftime('%Y%m%d')
#    url =reverse("account:account_list")
    #return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))

def account_redirect_view(request):
    date_str = datetime.now().strftime('%Y-%m-%d')
    return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))

class AccountListView(ListView):
    def get(self, request, date_str, *args, **kwargs):
        query_date = request.GET.get('selected_date', None)
        if(query_date):
            return redirect(reverse("account:account_list", kwargs={"date_str" : query_date}))
        print('AccountListView - get:%s' % date_str)
        dt = datetime.strptime(date_str, '%Y-%m-%d').date()
        record_list = AccountRecord.objects.filter(date=dt)
        form = RecordListForm()
        context={
            'record_list' : record_list,
            'date_str' : date_str,
            'form' : form,
        }
        return render(request, 'account/list.html', context)

class AccountAddView(TemplateView):
    def get(self, request, date_str, *args, **kwargs):
        form = RecordEditForm(initial =
        {
            'date' : datetime.strptime(date_str, '%Y-%m-%d').date(),
        })
        context={
            'form' : form,
            'date_str' : date_str,
        }
        return render(request, 'account/add.html', context)
    def post(self, request, date_str, *args, **kwargs):
        print('AccountAddView - post:%s' % date_str)       
        form = RecordEditForm(request.POST)
        context={
            'form' : form,
            'date_str' : date_str,
        }
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/add.html', context)        
        record = form.save()
        date_str = record.date.strftime('%Y-%m-%d')
        return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))        


class AccountEditView(TemplateView):
    def get(self, request, id, *args, **kwargs):
        record = get_object_or_404(AccountRecord, pk=id)
        form = RecordEditForm(initial =
        {
            'ammount' : record.ammount,
            'resource' : record.resource,
            'category' : record.category,
            'date' : record.date,
            'memo' : record.memo,
        })
        context={
            'record' : record,
            'form' : form,
            'date_str' : record.date.strftime('%Y%m%d'),
        }
        return render(request, 'account/edit.html', context)

    def post(self, request, id, *args, **kwargs):
        record = get_object_or_404(AccountRecord, pk=id)
        form = RecordEditForm(request.POST, instance = record)
        context={
            'record' : record,
            'form' : form,
            'date_str' :  record.date.strftime('%Y-%m-%d'),    # not form.is_validの時の為
        }
        if not form.is_valid():
            messages.info(request, 'データに誤りがあります。')
            return render(request, 'account/edit.html', context)        

        form.save()
        
        date_str = record.date.strftime('%Y-%m-%d')
        return redirect(reverse("account:account_list", kwargs={"date_str" : date_str}))


class AccountSearchView(ListView):
    def get(self, request, *args, **kwargs):
        dt_from = datetime.strptime('2022-02-01', '%Y-%m-%d').date()
        dt_to = datetime.strptime('2022-02-28', '%Y-%m-%d').date()
        record_list = AccountRecord.objects.filter(date__range=[dt_from, dt_to]).order_by('date')
        context={
            'record_list' : record_list,
        }
        return render(request, 'account/search.html', context)


class AccountSumupView(ListView):
    def get(self, request, *args, **kwargs):
        dt_from = datetime.strptime('2022-01-01', '%Y-%m-%d').date()
        dt_to = datetime.strptime('2022-01-31', '%Y-%m-%d').date()
        sumup_list=[]
        for ct in AccountCategory.objects.all():
            targets = AccountRecord.objects.filter(date__range=[dt_from, dt_to]).filter(category=ct).all()
            print(ct.name)
            sumup_list.append({
                'category': ct.name,
                'sum': targets.aggregate(total_ammount=Sum("ammount")),
            })

        context={
            'sumup_list' : sumup_list,
        }
        return render(request, 'account/sumup.html', context)